package com.turk.asistan

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import org.json.JSONObject

class AssistantService : Service(), TextToSpeech.OnInitListener {
    companion object {
        const val ACTION_CLOSE_APP = "com.turk.asistan.CLOSE_APP"
        private const val CHANNEL_ID = "turk_assistant"
        private const val NOTIFICATION_ID = 7

        // Sonraki adımda kendi PHP sunucunun HTTPS adresi buraya yazılacak.
        // API anahtarı Android uygulamasına kesinlikle konulmayacak.
        private const val AI_ENDPOINT = "https://YOUR-DOMAIN.example/turk-chat.php"
    }

    private var speech: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var listening = false
    private var ready = false
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        createNotification()
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speech = SpeechRecognizer.createSpeechRecognizer(this)
            speech?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { scheduleListen(900) }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val phrase = words?.firstOrNull()?.lowercase(Locale("tr", "TR")).orEmpty()
                    handlePhrase(phrase)
                    scheduleListen(900)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        } else speak("Bu telefonda ses tanıma kullanılamıyor.")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        listening = true
        scheduleListen(500)
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Türk Asistan", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Türk dinlemede")
            .setContentText("Durdurmak için uygulamayı aç.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun scheduleListen(delay: Long) {
        handler.postDelayed({
            if (listening && speech != null) {
                try {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    }
                    speech?.startListening(intent)
                } catch (_: Exception) { scheduleListen(1500) }
            }
        }, delay)
    }

    private fun handlePhrase(text: String) {
        if (text.isBlank()) return
        when {
            text.contains("kendini kapat") || text == "kapan" || text.contains("uygulamayı kapat") -> {
                speak("Kapanıyorum.")
                handler.postDelayed({
                    sendBroadcast(Intent(ACTION_CLOSE_APP).setPackage(packageName))
                    stopSelf()
                }, 900)
            }
            text == "türk" || text.startsWith("türk ") || text.contains("hey türk") -> {
                speak("Buradayım, seni dinliyorum.")
            }
            text.contains("saat kaç") -> {
                val now = java.text.SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(java.util.Date())
                speak("Saat $now")
            }
            text.contains("merhaba") || text.contains("selam") -> speak("Merhaba. Ben Türk.")
            else -> askOnlineAI(text)
        }
    }

    // İnternet varsa soruyu güvenli sunucuya gönderir.
    // Sunucu erişilemiyorsa kullanıcıya çevrimdışı olduğunu söyler.
    private fun askOnlineAI(message: String) {
        Thread {
            var answer: String? = null
            try {
                val connection = (URL(AI_ENDPOINT).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 10000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val payload = JSONObject().put("message", message).toString()
                connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
                val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                answer = JSONObject(body).optString("reply").takeIf { it.isNotBlank() }
                connection.disconnect()
            } catch (_: Exception) {
                answer = null
            }
            handler.post {
                if (answer != null) speak(answer!!)
                else speak("Şu anda çevrimdışıyım. Temel komutlarımı kullanabilirsin.")
            }
        }.start()
    }

    private fun speak(message: String) {
        if (ready) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "turk_tts")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("tr", "TR"))
            ready = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    override fun onDestroy() {
        listening = false
        handler.removeCallbacksAndMessages(null)
        speech?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}\n