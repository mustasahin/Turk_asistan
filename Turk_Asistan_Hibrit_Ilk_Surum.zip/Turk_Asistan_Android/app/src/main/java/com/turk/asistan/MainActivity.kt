package com.turk.asistan

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import android.view.Gravity

class MainActivity : Activity() {
    private val stopReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        val title = TextView(this).apply {
            text = "TÜRK"
            textSize = 34f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Türkçe sesli asistan\n\nBaşlat'a dokun ve 'Türk' diye seslen."
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 32)
        }
        val start = Button(this).apply {
            text = "ASİSTANI BAŞLAT"
            setOnClickListener { requestAndStart() }
        }
        val stop = Button(this).apply {
            text = "DİNLEMEYİ DURDUR"
            setOnClickListener {
                stopService(Intent(this@MainActivity, AssistantService::class.java))
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)

        val filter = IntentFilter(AssistantService.ACTION_CLOSE_APP)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stopReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(stopReceiver, filter)
    }

    private fun requestAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 100)
        } else startAssistant()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == 100 && r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) {
            startAssistant()
        } else Toast.makeText(this, "Mikrofon izni gerekli.", Toast.LENGTH_LONG).show()
    }

    private fun startAssistant() {
        val intent = Intent(this, AssistantService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "Türk dinlemeye başladı.", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        try { unregisterReceiver(stopReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
