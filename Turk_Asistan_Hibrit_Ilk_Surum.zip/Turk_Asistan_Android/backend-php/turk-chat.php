<?php
// Türk Asistan için örnek sunucu uç noktası.
// API anahtarını bu dosyaya yazmayın; hosting ortam değişkeninden okuyun.
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'POST gerekli'], JSON_UNESCAPED_UNICODE);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$message = trim($input['message'] ?? '');
if ($message === '' || mb_strlen($message) > 4000) {
    http_response_code(400);
    echo json_encode(['error' => 'Geçersiz mesaj'], JSON_UNESCAPED_UNICODE);
    exit;
}

$apiKey = getenv('OPENAI_API_KEY');
if (!$apiKey) {
    http_response_code(500);
    echo json_encode(['error' => 'Sunucu API anahtarı ayarlanmamış'], JSON_UNESCAPED_UNICODE);
    exit;
}

// Burada OpenAI API'ye sunucu tarafından istek gönderilecek.
// API modeli ve endpoint'i kuruluma başlamadan önce güncel dokümana göre seçilecek.
// Bu örnek, yanlış/eskimiş endpoint kullanmamak için bilerek tamamlanmamıştır.
http_response_code(501);
echo json_encode([
    'error' => 'AI bağlantısı henüz yapılandırılmadı',
    'reply' => 'Çevrimiçi yapay zekâ bağlantısı sunucuda yapılandırılmayı bekliyor.'
], JSON_UNESCAPED_UNICODE);\n