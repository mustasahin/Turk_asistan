# Türk Asistan — Hibrit Android prototipi

## Çalışma mantığı
- Çevrimdışı: Türkçe ses tanıma servisi destekliyorsa temel komutlar (`merhaba`, `saat kaç`, `kapan`).
- Çevrimiçi: Tanınan diğer cümleler HTTPS üzerinden sizin sunucu uç noktanıza gönderilir.
- Sesli yanıt: Android Türkçe TTS motoru.

## Android Studio
1. ZIP'i çıkarıp klasörü Android Studio ile açın.
2. Gradle senkronizasyonunu tamamlayın.
3. Android telefonunuzda mikrofon iznini verin.
4. Asistanı Başlat'a dokunun. Dinleme, görünür bildirimle çalışır.

## Çevrimiçi yapay zekâ bağlantısı
`AssistantService.kt` içindeki `AI_ENDPOINT` değerini kendi HTTPS PHP adresinizle değiştirin.
`backend-php/turk-chat.php` yalnızca örnek iskelettir; AI API çağrısı henüz tamamlanmamıştır.
Sunucu tarafında API anahtarı gizli tutulmalıdır. Anahtarı APK içine koymayın.
Sunucu tarafındaki OpenAI API endpoint/modeli, güncel resmi API belgelerine göre ayrıca yapılandırılmalıdır.

## Bilinen sınırlar
- Bu sürüm hazır APK değildir; Android Studio ile derlenmelidir.
- Android `SpeechRecognizer`, gerçek bir sürekli "Hey Türk" uyandırma motoru değildir. Tanıma oturumları cihaz ve Android sürümüne göre kesilebilir; sistemin ses tanıma servisi internet isteyebilir.
- Arka planda mikrofon kullanımı Android'in görünür foreground-service bildirimi ve izinlerine tabidir. Android kullanıcı/işletim sistemi kısıtlamalarını aşamaz.
- Çevrimdışı ses tanıma, telefonda Türkçe çevrimdışı dil paketi bulunmasına ve cihaz desteğine bağlıdır.
- Çevrimdışı genel yapay zekâ sohbeti henüz ekli değildir; bu sürümde yalnızca temel yerel komutlar çevrimdışı çalışır.\n